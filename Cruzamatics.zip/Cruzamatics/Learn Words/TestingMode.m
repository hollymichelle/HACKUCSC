

#import "TestingMode.h"
#include <stdlib.h>



@interface TestingMode ()


@end


@implementation TestingMode;


int questions_index;
int in_value;
int levels;
NSString *input;

@synthesize TF_answer;



//static NSArray *q_array = nil;
//static NSArray *a_array = nil;




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil

{
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        
        // Custom initialization
        
    }
    
    return self;
    
}


- (void)viewDidLoad
{
    
    //set main game hidden
    questions_index = 0;
    level.text = @"Level: White";
    level.textColor = [UIColor darkGrayColor];
    
    [level setHidden:YES];
  //  [scores setHidden:YES];
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    [TF_questions setHidden:YES];
    [TF_answer setHidden:YES];
    [TF_labelAnswer setHidden:YES];
    [TF_results setHidden:YES];
    [nextQuestion setHidden:YES];
    
  //  [inter_fact setHidden:YES];
    [trivia setHidden:YES];
    
    
    
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    
}

//TF_question = YES;

- (void)didReceiveMemoryWarning

{
    
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
    
}






-(IBAction)LetsGetStarted:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Note" message:@"If your stuck click on the instructions button at the bottom left!\n\nIf you had enough fun and want to exit click on the exit button on the bottom right!" delegate:self cancelButtonTitle:@"Ok!" otherButtonTitles:nil];
    
    [alert show];
    
    [self presentSchool];
    
    
}


-(void) presentSchool{
    
    questions_index = 0;
    
    [LetsGetStarted setHidden:YES];
    [story setHidden:YES];
    [TF_answer setHidden:YES];
    [TF_questions setHidden:YES];
    [TF_results setHidden:YES];
    [trivia setHidden:YES];
    [TF_labelAnswer setHidden:YES];
    
    [level setHidden:NO];
 //   [scores setHidden:NO];
    
    [schoolMap setHidden:NO];
    [Davenport setHidden:NO];
    [BonnyDoon setHidden:NO];
    
    
    [SantaCruz setHidden:NO];
    [ScottsValley setHidden:NO];
    [Capiotola setHidden:NO];
    [Soquel setHidden:NO];
    [Aptos setHidden:NO];
    [Corralitos setHidden:NO];
    [Watsonville setHidden:NO];
    

}

-(IBAction)help_instructions:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Instructions" message:@"Select a High School!\n\n Each High School has atleast 3 math triva questions that will teach you something you may not know about Santa Cruz!\n\n When you answer all the questions correctly, you will be rewarded an interesting fact about Santa Cruz!\n\n " delegate:self cancelButtonTitle:@"Ready" otherButtonTitles:nil];
    
    [alert show];
}

-(IBAction)button_exit:(id)sender{
    
    schoolMap.image = [UIImage imageNamed:@"schools_map.png"];
    schoolMap.alpha = 1.0f;
    if (questions_index == 0)
     [self.navigationController popToRootViewControllerAnimated:YES];
    
    else
        [self presentSchool];
}



-(IBAction)Davenport_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now Entering Georginia Bruce Kirby Prepatory School" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    
    
}


-(IBAction)BonnyDoon_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now Entering San Lorenzo High School" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    
}


-(IBAction)SantaCruz_Click:(id)sender{
    
   // [schoolMap setHidden:YES];
    schoolMap.image = [UIImage imageNamed:@"Picture 10.png"];
    schoolMap.alpha = 0.5f;

    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    [TF_questions setHidden:NO];
    [TF_answer setHidden:NO];
    [TF_labelAnswer setHidden:NO];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now Entering Santa Cruz High School\n" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show]; 
    questions_index = 1;
    
    [self presentQuestions];
    //NSString *input = TF_answer.text;
    

    //[TF_results setHidden:YES];
    
}

-(IBAction)ScottsValley_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now Entering Scotts Valley School\n" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    
    
}

-(IBAction)Capiotola_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now entering Harbor High School" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    
    
}

-(IBAction)Soquel_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    [Davenport setHidden:YES];
    [BonnyDoon setHidden:YES];
    [SantaCruz setHidden:YES];
    [ScottsValley setHidden:YES];
    [Capiotola setHidden:YES];
    [Soquel setHidden:YES];
    [Aptos setHidden:YES];
    [Corralitos setHidden:YES];
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now entering Soquel High School\n" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
}

-(IBAction)Aptos_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now entering Aptos High School" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    
    
}

-(IBAction)Corralitos_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    
    [Davenport setHidden:YES];
    
    [BonnyDoon setHidden:YES];
    
    [SantaCruz setHidden:YES];
    
    [ScottsValley setHidden:YES];
    
    [Capiotola setHidden:YES];
    
    [Soquel setHidden:YES];
    
    [Aptos setHidden:YES];
    
    [Corralitos setHidden:YES];
    
    [Watsonville setHidden:YES];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Traveling" message:@"Now entering St.Francis\n" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    
    
}

-(IBAction)Watsonville_Click:(id)sender{
    
    [schoolMap setHidden:YES];
    [Davenport setHidden:YES];
    [BonnyDoon setHidden:YES];
    [SantaCruz setHidden:YES];
    [ScottsValley setHidden:YES];
    [Capiotola setHidden:YES];
    [Soquel setHidden:YES];
    [Aptos setHidden:YES];
    [Corralitos setHidden:YES];
    [Watsonville setHidden:YES];
    
    [TF_questions setHidden:NO];
    [TF_answer setHidden:NO];
    [TF_labelAnswer setHidden:NO];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Watsonville" message:@"Now entering Watsonville high school\n" delegate:self cancelButtonTitle:@"Let's Go" otherButtonTitles:nil];
    
    [alert show];
    
    questions_index = 5;
    [self presentQuestions];
    
    
    
}

-(IBAction)trivia_click:(id)sender
{
    if (questions_index == 4 || questions_index == 8){
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Interesting Fact #1" message:@"Did you know?\n\n Ohlone Native Americans inhabited the area now known as Santa Cruz long before any Europeans laid eyes upon the land.\n The region was officially discovered in 1769 when Spanish explorer Gaspar de Portola stumbled upon it while he was traveling to Monterey. He named the river that cuts through the valley floor and flows into the sea 'San Lorenzo' and the rolling hills from which the river comes Santa Cruz'" delegate:self cancelButtonTitle:@"Wow, Thanks!" otherButtonTitles:nil];
        
    [alert show];
        levels++;
    }
    
    if (levels == 1)
    {
        level.text = @"Yellow Belt";
        level.textColor = [UIColor colorWithRed:178.0/255 green:178.0/255 blue:34.0/255 alpha:1 ];
    }
    else if (levels == 2)
    {
        level.text = @"Orange Belt";
        level.textColor = [UIColor orangeColor ];
    }
    else if (levels == 3)
    {
        level.text = @"Green Belt";
        level.textColor = [UIColor greenColor ];
    }
    else if (levels == 4)
    {
        level.text = @"Purple Belt";
        level.textColor = [UIColor purpleColor ];
    }
    else if (levels == 5)
    {
        level.text = @"Blue Belt";
        level.textColor = [UIColor blueColor ];
    }
    else if (levels == 6)
    {
        level.text = @"Brown Belt";
        level.textColor = [UIColor brownColor ];
    }
    else if (levels == 7)
    {
        level.text = @"Black Belt";
        level.textColor = [UIColor blackColor ];
    }
    else if (levels == 8)
    {
        level.text = @"Rainbow Belt";
        level.textColor = [UIColor redColor ];
    }
    else if (levels == 9)
    {
        level.text = @"Santa Cruz Belt";
        level.textColor = [UIColor magentaColor ];
    }
    
    
    
}


- (IBAction)TF_answer_action:(id)sender {
    
    [sender resignFirstResponder];

    [ self checkAnswers ] ;
    
    
    
}

- (void) checkAnswers{
    
    input = TF_answer.text;
    
    if (questions_index == 1){
        if([input isEqualToString:(@"26.6") ]) {
        
        [TF_results setHidden:NO];
        TF_results.text = @"Yes that is right! Good Job!";
        TF_answer.text = @"";
        questions_index++;
        
        [nextQuestion setTitle:(@"Next Question!") forState:UIControlStateNormal];
        [nextQuestion setHidden:NO];

        } else {
      
        [TF_results setHidden:NO];
       
        TF_results.text = @"Hint xx.6";
        }
    }
    else if (questions_index == 2){
        if([input isEqualToString:(@"74303") ]) {
            [TF_results setHidden:NO];
        
            TF_results.text = @"Yes that is right! Good Job!";
            questions_index++;
            [nextQuestion setTitle:(@"Next Question!") forState:UIControlStateNormal];
            [nextQuestion setHidden:NO];
        } else {
            [TF_results setHidden:NO];
            TF_results.text = @"Hint!\n Five digits, multiplication is the key!";
        }
    }
    else if (questions_index  == 3)
    {
        if([input isEqualToString:(@"5380")]) {
            [TF_results setHidden:NO];
            TF_results.text = @"Yes that is right! Good Job!";
            questions_index++;
            
            [nextQuestion setTitle:(@"Next?") forState:UIControlStateNormal];
            [nextQuestion setHidden:NO];
    
        } else {
            [TF_results setHidden:NO];
            TF_results.text = @"Hint!\n Four digits, multiplication is the key!";
        }
    }
    else if (questions_index == 5){
        
        if([input isEqualToString:(@"111")]) {
            [TF_results setHidden:NO];
            TF_results.text = @"Yes that is right! Good Job!";
            questions_index++;
            
            [nextQuestion setTitle:(@"Next?") forState:UIControlStateNormal];
            [nextQuestion setHidden:NO];
            
        } else {
            [TF_results setHidden:NO];
            TF_results.text = @"Hint!\n Four digits, multiplication is the key!";
        }

        
    }
    else if (questions_index >= 5 && questions_index <= 8){
        
        if([input isEqualToString:(@"111")]) {
            [TF_results setHidden:NO];
            TF_results.text = @"Correct answer place holder!";
            questions_index++;
            
            [nextQuestion setTitle:(@"Next place holder...") forState:UIControlStateNormal];
            [nextQuestion setHidden:NO];
            
        } else {
            [TF_results setHidden:NO];
            TF_results.text = @"Hint!\n A hint for the player";
        }
        
        
    }

    
}

- (void) presentQuestions{
    
    [nextQuestion setTitle:(@"") forState:UIControlStateNormal];
    [nextQuestion setHidden:YES];

    if(questions_index == 1) {
        TF_questions.text = @"Four hundred forty five square miles of Santa Cruz county is land and 161 square miles of Santa Cruz county is water\n\n What percentage of Santa Cruz county is water?\n\nRemember to tound to the nearest tenths and no need for '%' sign";
        }
    
    else if(questions_index == 2) {
        TF_questions.text = @"The population of Santa Cruz County is 256,218, and twenty nine percent of the population is Hispanic.\n  How many people who live in Santa Cruz County are Hispanic?\n\n Remember to round down!";
        }
    
    else if(questions_index == 3) {
        TF_questions.text = @"The population of Santa Cruz County is 256,218, and 2.1% of the population is American Indian.  How many people who live in Santa Cruz County are American Indian\n\n Remember to round down!";
        
    }
    else if( questions_index == 4) {
       
        TF_questions.text = @"Congratulations!\n\n You unclocked an interesting trivia!";
        [TF_labelAnswer setHidden:YES];
        [TF_answer setHidden:YES];
        [trivia setHidden:NO];
        
    }
    else if(questions_index == 5) {
        TF_questions.text = @"This is a 1st place holder for Watsonville";
    }
    else if(questions_index == 6) {
        TF_questions.text = @"This is a 2nd place holder for Watsonville";
        
    }

    else if(questions_index == 7) {
        TF_questions.text = @"This is a 3rd place holder for Watsonville";
        
    }
    else if(questions_index == 8) {
        TF_questions.text = @"This is trivia place holder";
        
    }



}

- (IBAction)nextQuestion:(id)sender{
    TF_answer.text = @"";
    TF_results.text = @"";
    [self presentQuestions];
}


//[self.navigationController popToRootViewControllerAnimated:YES];

@end