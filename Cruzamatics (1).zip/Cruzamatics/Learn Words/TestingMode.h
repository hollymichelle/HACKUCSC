//

//  TestingMode.h


//  Copyright (c) 2014 Psyentific Mind. All rights reserved.

//


#import <UIKit/UIKit.h>


@interface TestingMode : UIViewController

{
    
    NSMutableArray *sounds;
    
    int goodAnswer;
    
    NSArray *temp;
    
    NSMutableArray *collector;
    
    //intro buttons
    
    IBOutlet UITextView *story;
    IBOutlet UIButton *LetsGetStarted;
    
    IBOutlet UIButton *help;
    IBOutlet UIButton *quit;
    IBOutlet UIButton *nextQuestion;
    
    IBOutlet UIImageView *schoolMap;
    IBOutlet UIImageView *background;
    
    IBOutlet UILabel *level;
//IBOutlet UILabel *scores;
    
    
    //school buttons
    
    IBOutlet UIButton *Davenport;
    IBOutlet UIButton *BonnyDoon;
    IBOutlet UIButton *SantaCruz;
    IBOutlet UIButton *ScottsValley;
    IBOutlet UIButton *Capiotola;
    IBOutlet UIButton *Soquel;
    IBOutlet UIButton *Aptos;
    IBOutlet UIButton *Corralitos;
    IBOutlet UIButton *Watsonville;
    
    //responses
    IBOutlet UILabel *TF_questions;
    IBOutlet UILabel *TF_labelAnswer;
    IBOutlet UILabel *TF_results;
    
    //trivia
    IBOutlet UIButton *trivia;
    
    
}


//intro clicks

@property (weak, nonatomic) IBOutlet UITextField *TF_answer;
- (IBAction)TF_answer_action:(id)sender;

- (IBAction)LetsGetStarted:(id)sender;
- (IBAction)help_instructions:(id)sender;
- (IBAction)button_exit:(id)sender;
- (IBAction)nextQuestion:(id)sender;

//map clicks

- (IBAction)Davenport_Click:(id)sender;

- (IBAction)BonnyDoon_Click:(id)sender;

- (IBAction)SantaCruz_Click:(id)sender;

- (IBAction)ScottsValley_Click:(id)sender;

- (IBAction)Capiotola_Click:(id)sender;

- (IBAction)Soquel_Click:(id)sender;

- (IBAction)Aptos_Click:(id)sender;

- (IBAction)Corralitos_Click:(id)sender;

- (IBAction)Watsonville_Click:(id)sender;

- (IBAction)trivia_click:(id)sender;








@end