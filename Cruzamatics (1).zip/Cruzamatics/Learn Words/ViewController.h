//
//  ViewController.h
//  Learn Words
//
//  Created by Sanjay Nadhavajhala on 2/12/14.
//  Copyright (c) 2014 Psyentific Mind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
