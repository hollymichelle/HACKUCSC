//
//  ViewController.m
//  Learn Words
//
//  Created by Sanjay Nadhavajhala on 2/12/14.
//  Copyright (c) 2014 Psyentific Mind. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
        
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
